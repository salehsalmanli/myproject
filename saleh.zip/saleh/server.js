const express = require('express'); // Ekspress serveri yükləyirik
const { DatabaseSync } = require('node:sqlite'); // Daxili məlumat bazası (SQLite)

const app = express(); // Backend serveri yaradırıq
const db = new DatabaseSync('database.sqlite'); // database.sqlite faylına qoşuluruq

// Formdan gələn dataları oxumaq üçün vacibdir
app.use(express.urlencoded({ extended: true }));

// Bütün HTML fayllarını (index.html, vs) brauzerə verə bilmək üçün
app.use(express.static(__dirname));

// Əgər users cədvəli yoxdursa, username və password olan cədvəl yaradırıq
db.exec("CREATE TABLE IF NOT EXISTS users (username TEXT, password TEXT)");

// Qeydiyyat POST sorğusu
app.post('/register', (req, res) => {
    // Sırf login və parolu bazaya əlavə edirik (Ad formdan və bazadan silindi)
    const stmt = db.prepare('INSERT INTO users (username, password) VALUES (?, ?)');
    stmt.run(req.body.user, req.body.pass);
    
    // Uğurlu əlavədən sonra giriş səhifəsinə atırıq
    res.redirect('/index.html');
});

// Giriş (Login) POST sorğusu
app.post('/login', (req, res) => {
    // Siz yazdığınız kimi SQL Injection-a bilərəkdən açıq saxlanıb
    const query = `SELECT * FROM users WHERE username = '${req.body.username}' AND password = '${req.body.password}'`;
    
    // Sorğunu birbaşa icra edilib nəticəni alırıq
    const user = db.prepare(query).get();

    // Əgər true olarsa (yəni tapıldısa), panelə buraxırıq
    if (user) {
        res.redirect('/dashboard.html');
    } else {
        // Tapılmadısa xəta qaytarırıq
        res.send("Sehvdir! <a href='/index.html'>Geri</a>");
    }
});

// Server 8000-ci port üzərindən işə düşür
app.listen(8000, () => {
    console.log("Server qosuldu");
});